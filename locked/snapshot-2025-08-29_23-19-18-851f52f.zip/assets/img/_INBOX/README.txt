Drop any raw images for the site here.

Accepted formats: .jpg .jpeg .png .webp .tif .tiff
Tips:
- Please avoid HEIC if possible (export to JPG/PNG).
- Original resolution is fine; I will downscale and optimize.

After adding images, ping me and I’ll place them in the site.

